from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from lefort.models import Users



# Create your views here.
def index(request):
       template = loader.get_template('lefort/login.html')
       return HttpResponse(template.render(request))

def signup(request):
	template = loader.get_template('lefort/register.html')
	return HttpResponse(template.render(request))
