from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Users(models.Model):
	firstname = models.CharField(max_length=32)
	lastame = models.CharField(max_length=32)
	username = models.CharField(max_length=32)
	password = models.CharField(max_length=32)
	email = models.EmailField(max_length=32)
	date = models.DateTimeField()